# Tmate VPS Creator Discord Bot

Create 24/7 temporary VPS sessions using Tmate via Discord. Each user gets a unique persistent session.

## Features

- Persistent SSH sessions
- Web-based access
- SQLite or JSON session storage
- Admin-only control
- Dashboard via Flask web app
- Preinstall templates (Minecraft, AMP, Pterodactyl)

## Setup

1. Clone the repo:

```bash
git clone https://yourrepo.git
cd yourrepo
