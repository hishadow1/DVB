import json
import os

class JSONStorage:
    def __init__(self):
        self.file = "storage/sessions.json"
        os.makedirs("storage", exist_ok=True)

    def load_sessions(self):
        if os.path.exists(self.file):
            with open(self.file, "r") as f:
                return json.load(f)
        return {}

    def save_sessions(self, sessions):
        with open(self.file, "w") as f:
            json.dump(sessions, f, indent=2)