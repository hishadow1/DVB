import sqlite3
import json
import os

class SQLiteStorage:
    def __init__(self):
        os.makedirs("storage", exist_ok=True)
        self.conn = sqlite3.connect("storage/sessions.db")
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS sessions (user_id TEXT PRIMARY KEY, data TEXT)"
        )

    def load_sessions(self):
        cur = self.conn.execute("SELECT user_id, data FROM sessions")
        return {row[0]: json.loads(row[1]) for row in cur.fetchall()}

    def save_sessions(self, sessions):
        self.conn.execute("DELETE FROM sessions")
        for uid, data in sessions.items():
            self.conn.execute(
                "INSERT INTO sessions (user_id, data) VALUES (?, ?)",
                (uid, json.dumps(data)),
            )
        self.conn.commit()