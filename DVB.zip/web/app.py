from flask import Flask, render_template, session
import json

app = Flask(__name__)
app.secret_key = 'supersecretkey'

@app.route('/')
def dashboard():
    try:
        with open('storage/sessions.json') as f:
            sessions = json.load(f)
    except:
        sessions = {}

    return render_template('dashboard.html', sessions=sessions)