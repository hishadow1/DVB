import subprocess
import asyncio

async def create_tmate_session():
    proc = await asyncio.create_subprocess_exec(
        "tmate", "-S", "/tmp/tmate.sock", "new-session", "-d"
    )
    await proc.communicate()

    await asyncio.create_subprocess_exec("tmate", "-S", "/tmp/tmate.sock", "wait", "tmate-ready")

    output = await asyncio.create_subprocess_shell(
        "tmate -S /tmp/tmate.sock display -p '#{tmate_ssh}'",
        stdout=asyncio.subprocess.PIPE
    )
    stdout, _ = await output.communicate()
    ssh = stdout.decode().strip()

    output = await asyncio.create_subprocess_shell(
        "tmate -S /tmp/tmate.sock display -p '#{tmate_web}'",
        stdout=asyncio.subprocess.PIPE
    )
    stdout, _ = await output.communicate()
    web = stdout.decode().strip()

    return {
        "ssh": ssh,
        "web": web
    }