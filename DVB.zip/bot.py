import discord
from discord.ext import commands
import json
from session_manager import SessionManager

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

with open("config.json") as f:
    config = json.load(f)

session_manager = SessionManager()

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")
    await session_manager.restore_sessions(bot)

@bot.command()
async def create(ctx):
    session = await session_manager.create_session(ctx.author.id)
    await ctx.send(f"🔗 Your VPS: `{session['ssh']}`")

@bot.command()
async def extend(ctx):
    success = session_manager.extend_session(ctx.author.id)
    await ctx.send("✅ Session extended." if success else "❌ No session to extend.")

@bot.command()
async def stop(ctx):
    success = await session_manager.stop_session(ctx.author.id)
    await ctx.send("🛑 VPS stopped." if success else "❌ No active VPS.")

@bot.command()
async def list(ctx):
    sessions = session_manager.list_sessions()
    if not sessions:
        await ctx.send("📭 No active sessions.")
        return
    msg = "\n".join(f"{s['user_id']}: {s['ssh']}" for s in sessions)
    await ctx.send(f"📋 Active VPS Sessions:\n{msg}")

bot.run(config["token"])
