import json
import asyncio
from storage.sqlite_store import SQLiteStorage
from storage.json_store import JSONStorage
from utils.tmate_utils import create_tmate_session

class SessionManager:
    def __init__(self):
        from config import config
        self.storage = SQLiteStorage() if config["storage"] == "sqlite" else JSONStorage()
        self.sessions = self.storage.load_sessions()

    async def create_session(self, user_id):
        if str(user_id) in self.sessions:
            return self.sessions[str(user_id)]
        session = await create_tmate_session()
        session["user_id"] = user_id
        self.sessions[str(user_id)] = session
        self.storage.save_sessions(self.sessions)
        return session

    def extend_session(self, user_id):
        if str(user_id) not in self.sessions:
            return False
        # Could add expiry update logic
        return True

    async def stop_session(self, user_id):
        if str(user_id) in self.sessions:
            del self.sessions[str(user_id)]
            self.storage.save_sessions(self.sessions)
            return True
        return False

    def list_sessions(self):
        return list(self.sessions.values())

    async def restore_sessions(self, bot):
        self.sessions = self.storage.load_sessions()
